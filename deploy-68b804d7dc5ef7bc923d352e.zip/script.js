// p5.js sketch
let particles = [];
let showText = false;
let mousePressStart = null;
let lastInteraction = null;
let inactivityTimeout = null;

function setup() {
    let canvas = createCanvas(windowWidth, windowHeight);
    canvas.parent('sketch-holder');

    for (let i = 0; i < 200; i++) {
        particles.push({
            pos: createVector(random(width), random(height)),
            vel: createVector(random(-1, 1), random(-1, 1)),
            size: random(45, 65),
            baseColor: color(random(100, 150), random(10, 250), 255),
            startColor: color(random(50, 100), random(50, 150), 200, 180),
            endColor: color(random(50, 100), random(50, 100), 100, 180),
            color: null
        });
        particles[i].color = particles[i].baseColor;
    }
    textAlign(CENTER, CENTER);
    textFont('ms sans serif');

    const hint = document.getElementById('hint');
    hint.classList.remove('hidden');

    lastInteraction = millis();
    startInactivityTimer();
}

function draw() {
    for (let y = 0; y < height; y++) {
        let c = lerpColor(color(210, 170, 250), color(190, 230, 250), y / height);
        stroke(c);
        line(0, y, width, y);
    }

    let closeCount = 0;

    for (let p of particles) {
        if (mouseIsPressed) {
            let dir = createVector(mouseX - p.pos.x, mouseY - p.pos.y);
            let distance = dir.mag();
            dir.setMag(map(distance, 0, width, 0.5, 1.5));
            p.vel.add(dir);
            p.color = lerpColor(p.color, color(255, 255, 200, 230), 0.05);
            if (distance < 20) closeCount++;
        } else {
            let angle = random(TWO_PI);
            let spiral = p5.Vector.fromAngle(angle).mult(random(1, 1.3));
            p.vel.add(spiral);
            p.color = lerpColor(p.color, p.baseColor, 0.02);
        }

        p.vel.mult(0.9);
        p.pos.add(p.vel);

        if (p.pos.x < 0 || p.pos.x > width) p.vel.x *= -1;
        if (p.pos.y < 0 || p.pos.y > height) p.vel.y *= -1;

        noStroke();
        fill(p.color);
        ellipse(p.pos.x, p.pos.y, p.size);
    }

    const hint = document.getElementById('hint');
    if (mouseIsPressed && closeCount > particles.length * 0.9) {
        showText = true;
        hint.classList.add('hidden');
    } else if (!mouseIsPressed) {
        showText = false;
        hint.classList.remove('hidden');
    }

    if (showText) {
        fill(250, 245, 250);
        let fontSize = min(width, height) * 0.1;
        textSize(max(fontSize, 20));
        text("будущее — это ты", width/2, height/2);
    }

    if (mouseIsPressed && mousePressStart && (millis() - mousePressStart > 4000)) {
        document.getElementById('sketch-holder').style.display = 'none';
        document.querySelector('.container').style.display = 'block';
        hint.classList.add('hidden');
        mousePressStart = null;
        lastInteraction = millis();
        startInactivityTimer();
    }
}

function mousePressed() {
    mousePressStart = millis();
    lastInteraction = millis();
    startInactivityTimer();
}

function mouseReleased() {
    mousePressStart = null;
}

function keyPressed() {
    lastInteraction = millis();
    startInactivityTimer();
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

function startInactivityTimer() {
    if (inactivityTimeout) {
        clearTimeout(inactivityTimeout);
    }
    inactivityTimeout = setTimeout(() => {
        if (document.querySelector('.container').style.display === 'block') {
            document.querySelector('.container').style.display = 'none';
            document.getElementById('sketch-holder').style.display = 'block';
            const intro = document.getElementById('intro');
            const scenarios = document.getElementById('scenarios');
            const quest = document.getElementById('quest');
            const hint = document.getElementById('hint');
            intro.classList.remove('hidden');
            scenarios.classList.remove('hidden');
            quest.classList.add('hidden');
            quest.classList.remove('fade-in');
            document.getElementById('restart').classList.add('hidden');
            hint.classList.remove('hidden');
            lastInteraction = millis();
            startInactivityTimer();
        }
    }, 160000);
}

// Quest JavaScript
const quests = {
    2: {
        name: "Технологический",
        steps: [
            {
                text: "Вы заказываете пиццу на ужин. Вас просят выбрать: доставщик робот или доставщик человек?",
                choices: [
                    { text: "Робот", next: 1, image: { src: "images/robot.jpg", alt: "Робот-доставщик" } },
                    { text: "Человек", next: 5, image: { src: "images/deliver.jpg", alt: "Человек-доставщик" } }
                ]
            },
            {
                text: "Роботы и дроны-доставщики теперь обыденность. Механический голос привычно желает приятного аппетита. А дети удивляются вашим рассказам о мифических курьерах с большими рюкзаками...",
                choices: [
                    { text: "Дальше", next: 2 }
                ]
            },
            {
                text: "Роботы и нейросети — повседневность. Мощные процессоры, считанные секунды... и ненужными становятся тысячи. Как же приятно отдать команду и избавить себя от скучной работы. Только вот вы стали замечать: что-то не так. То ли память подводит, то ли соображаешь хуже, наверное возраст. Но всему у технологий найдётся решение. Вставите имплант в мозг?",
                choices: [
                    { text: "Да", next: 3, image: { src: "images/impl.jpg", alt: "Нейроимплант" } },
                    { text: "Нет", end: "Перспектива вживить себе в голову что-то инородное пугает вас. Может, есть иные пути прогресса? Можно ли, идя назад, пройти вперёд?" }
                ]
            },
            {
                text: "Отныне вы больше, чем человек. Прямо-таки киберчеловек. Словно герой фантастического фильма, вы силой мысли управляете компьютерами и техникой. Бесконечные базы данных — продолжение вашей памяти. Нейросети — часть ваших мыслей. Вы можете чувствовать прикосновения, получая сигналы в мозг... В какой же реальности мы живём? Существует ли теперь реальность?",
                choices: [
                    { text: "Дальше", next: 4 }
                ]
            },
            {
                text: "Проводятся исследования по расширению возможностей разума животных. Вставите ли имплант своему коту? Обещают, что тогда он точно сможет поймать красную точку.",
                choices: [
                    { text: "Да", end: "Кот лежит на диване. Точнее, это вы лежите на диване, а кот — у вас на животе. Вы лениво поглядываете, как робоповар готовит ужин. Вкалывают роботы — счастлив человек. Теперь вы можете представить, каково было коту наблюдать, как вы его обслуживаете. Коты-киборги. Этот путь вероятного будущего... Может, вы сами станете его автором?" },
                    { text: "Нет", end: "Коты киборги захватили Петербург и отобрали у вашу квартиру. Вы пытались откупиться колбасой, но они давно питаются солнечной энергией. Кажется технологии зашли слишком далеко..." }
                ]
            },
            {
                text: "Даже в 2040 году люди продолжают работать доставщиками, официантами, продавцами вместе с роботами. Ваш любимый музыкальный исполнитель скончался. Несколько фанатов научили нейросеть создавать музыку и песни как у него. Будете слушать?",
                image: { src: "images/artist.jpg", alt: "Музыкальная сцена будущего" },
                choices: [
                    { text: "Буду слушать", next: 6 },
                    { text: "Нет", next: 8 }
                ]
            },
            {
                text: "Осень, изморось, промозгло. Погода всё хуже: то странное потепление не по сезону, то заморозки. Это уже слишком даже для Питера! Вы спешите домой, ведь сегодня концерт. Скорее бы надеть VR 12D очки... Сегодня выступает ваш любимый артист с новым альбомом. Пусть он и умер, за определённую плату его цифровой двойник будет петь вам хоть каждый вечер. Но это как-то слишком, вы выбрали подписку на ежемесячные концерты. Хм, что бы выбрать? Может, сегодня устроить концерт на Луне?",
                image: { src: "images/artist.jpg", alt: "Музыкальная сцена будущего" },
                choices: [
                    { text: "Дальше", next: 7 }
                ]
            },
            {
                text: "Вы чувствуете себя одиноко, хочется общения. Что выберете: пойти искать друзей в клуб по интересам или начать общаться с ИИ-другом?",
                choices: [
                    { text: "Общаться с ИИ-другом", end: "Солнце слепит глаза. Вы лежите на пляже. Нет ни запаха моря, ни горячего песка под ногами. Но этот виртуальный мир вполне неплох. Рядом ваш лучший друг. Очередная шахматная партия. Белый слон делает ход, вы ставите шах и мат. Ваш друг знает, что ему нужно проигрывать 67,79% партий, чтобы быть для вас идеальным. Может, поговорим о музыке? Но всё как-то однообразно..." },
                    { text: "Искать друзей среди людей", end: "Это было непросто, иногда казалось невозможным, но вы справились. Пробившись сквозь оковы алгоритмов, вы нашли настоящую дружбу. — Нет, ну ты понимаешь? Это как 'белая лошадь — не лошадь'. — Опять ты со своим бредом! При чём тут лошадь? Мы говорим о бутербродах! — Да нет же, это как 'у петуха три ноги'! Иногда ваш друг несёт чепуху, но с ним не соскучишься." }
                ]
            },
            {
                text: "Кажется, всё зашло слишком далеко. Это неэтично! Вы переслушиваете старые песни и находите новых исполнителей. Появляются активисты, ратующие за ограничения в использовании нейросетей. Создаются комитеты, появляется новое направление — техноэтика. ИИ остаётся лишь инструментом, помощником в рутинных задачах. Возможностей для творчества становится больше, воплощать идеи теперь проще.",
                choices: [
                    { text: "Дальше", next: 9 }
                ]
            },
            {
                text: "У вас появилось несколько свободных деньков. Как вы их проведёте?",
                choices: [
                    { text: "На природу", end: "Рвану куда-нибудь с палаткой, подальше от города. Нет ничего лучше тишины и природы. Тихо. Так тихо, что вы слышите собственное дыхание. Оно медленное, глубокое... Воздух напоен ароматом чая с брусникой и свежестью утра. Вы решили отдохнуть с палаткой на берегу Ладожского озера. Поразительно, но здесь даже интернет не ловит. Приятно спрятаться от суеты." },
                    { text: "Виртуальная реальность", end: "Вы надеваете шлем виртуальной реальности, погружаетесь в игру и оказываетесь в другом мире. Звуки, запахи, ощущения — всё настолько реалистично, что вы забываете, где находитесь. Вы можете почувствовать, как ветер развевает волосы, как под ногами хрустит песок. Вы можете выбрать один из тысяч виртуальных миров или создать свой. Но каждый раз наступает момент, когда приходится возвращаться. Некоторые выбирают остаться в виртуальном мире навсегда. Стоит ли и вам так попробовать?" }
                ]
            }
        ]
    }
};

function startQuest(scenarioId) {
    const intro = document.getElementById('intro');
    const scenarios = document.getElementById('scenarios');
    const quest = document.getElementById('quest');
    const hint = document.getElementById('hint');

    intro.classList.add('hidden');
    scenarios.classList.add('hidden');
    quest.classList.remove('hidden');
    quest.classList.add('fade-in');
    hint.classList.add('hidden');
    showStep(scenarioId, 0);
    lastInteraction = millis();
    startInactivityTimer();
}

function showStep(scenarioId, stepIndex) {
    const hint = document.getElementById('hint');
    hint.classList.add('hidden');

    const questData = quests[scenarioId];
    const step = questData.steps[stepIndex];
    if (!step) return;

    const questText = document.getElementById('quest-text');
    const questImages = document.getElementById('quest-images');
    questText.innerText = step.text;
    questText.classList.add('fade-in');

    questImages.innerHTML = '';
    if (step.image) {
        const img = document.createElement('img');
        img.src = step.image.src;
        img.alt = step.image.alt;
        img.classList.add('question-image');
        questImages.appendChild(img);
    }

    const choicesDiv = document.getElementById('choices');
    choicesDiv.innerHTML = '';

    step.choices.forEach(choice => {
        const button = document.createElement('button');
        const choiceContainer = document.createElement('div');
        choiceContainer.style.textAlign = 'center';

        if (choice.image) {
            const img = document.createElement('img');
            img.src = choice.image.src;
            img.alt = choice.image.alt;
            img.classList.add('choice-image');
            img.style.marginBottom = '10px';
            choiceContainer.appendChild(img);
        }

        button.innerText = choice.text;
        button.onclick = () => {
            questText.classList.remove('fade-in');
            if (choice.next !== undefined) {
                showStep(scenarioId, choice.next);
            } else if (choice.end) {
                endQuest(choice.end);
            }
            lastInteraction = millis();
            startInactivityTimer();
        };
        choiceContainer.appendChild(button);
        choicesDiv.appendChild(choiceContainer);
    });
}

function endQuest(message) {
    const hint = document.getElementById('hint');
    hint.classList.add('hidden');

    const questText = document.getElementById('quest-text');
    const questImages = document.getElementById('quest-images');
    questText.innerText = message;
    questText.classList.add('fade-in');
    questImages.innerHTML = '';
    document.getElementById('choices').innerHTML = '';

    const projectsContainer = document.createElement('div');
    projectsContainer.classList.add('projects-container');
    projectsContainer.innerHTML = `
        <div class="project-block">
            <img src="images/project1.jpg" alt="Проект 1">
            <p>Наш проект "Умный Город": Интеграция ИИ для оптимизации транспорта в Санкт-Петербурге. Узнайте больше на нашем сайте!</p>
        </div>
        <div class="project-block">
            <img src="images/project2.jpg" alt="Проект 2">
            <p>Инициатива "Цифровое Будущее": Обучение нейросетям для творчества. Присоединяйтесь к нашим воркшопам!</p>
        </div>
        <div class="project-block">
            <img src="images/project3.jpg" alt="Проект 3">
            <p>Проект "Эко-Тех": Сочетание технологий и экологии для устойчивого развития. Поддержите нас!</p>
        </div>
    `;
    questText.after(projectsContainer);

    document.getElementById('restart').classList.remove('hidden');
    lastInteraction = millis();
    startInactivityTimer();
}

function restartQuest() {
    const intro = document.getElementById('intro');
    const scenarios = document.getElementById('scenarios');
    const quest = document.getElementById('quest');
    const hint = document.getElementById('hint');

    intro.classList.remove('hidden');
    scenarios.classList.remove('hidden');
    quest.classList.add('hidden');
    quest.classList.remove('fade-in');
    document.getElementById('restart').classList.add('hidden');
    hint.classList.remove('hidden');

    showFeedback();
    lastInteraction = millis();
    startInactivityTimer();
}

function showFeedback() {
    const feedback = document.getElementById('feedback');
    feedback.classList.remove('hidden');
    feedback.classList.add('fade-in');
    feedback.innerHTML = `
        <h2>Обратная связь</h2>
        <p>Понравился квест? Поделитесь своими впечатлениями!</p>
        <form>
            <input type="text" placeholder="Ваше имя" required>
            <input type="email" placeholder="Ваш email" required>
            <textarea placeholder="Ваше сообщение" required></textarea>
            <button type="submit">Отправить</button>
        </form>
        <div class="contacts">
            <p>Свяжитесь с нами:</p>
            <p>Email: info@futurecity.spb.ru</p>
            <p>Телефон: +7 (812) 123-45-67</p>
            <p>Telegram: @FutureCitySPb</p>
        </div>
        <button id="return-button" onclick="returnToStart()">Вернуться на начало</button>
    `;
}

function returnToStart() {
    const feedback = document.getElementById('feedback');
    feedback.classList.add('hidden');
    feedback.classList.remove('fade-in');
    feedback.innerHTML = ''; // Очистка
}